# Especificación — Papeleta de Aptitud

## Formato
- Tamaño: media carta / A6.
- Elementos: Empresa, Paciente, Folio, QR, Fecha de emisión, Vigencia, Dictamen (Apto / Apto con restricciones / No apto), Semáforo global, hasta 3 restricciones, Médico validador (nombre y cédula), sellos/firmas.

## Flujo
- Se emite sólo tras validación y firma.
- QR → URL caducable (antifraude) con hash y sellado de tiempo.
- Reimpresiones: registradas en bitácora (quién/cuándo/motivo).