# Nomenclatura de archivos (propuesta)

/Empresa/Paciente/Folio/Estudio/AAAA-MM-DD/ArchivoOriginal.pdf

- Empresa: clave-corta (catálogo) + nombre canónico.
- Paciente: ApellidoPaterno_ApellidoMaterno_Nombres (sin acentos).
- Estudio: BH | EGO | QS24 | RX | ESP | AUDIO | ECG | CAMPI | RCV | EXMED | RESUMEN.
- Fechas en ISO (YYYY-MM-DD).