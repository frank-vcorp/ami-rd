# Estructura de DEMO (plantilla)

/01_fuentes_pdf/Empresa/Paciente/Folio/Estudio/AAAA-MM-DD/*.pdf
/02_json_extraccion/*.json
/03_reportes_pdf/*.pdf   (Reporte, Papeleta, Resumen)
/04_logs_bitacora/*.json (validación, firmas, versiones)

Coloca aquí los archivos para correr el demo interactivo.